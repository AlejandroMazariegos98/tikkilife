<?php 
require_once '../includes/db.php'; // The mysql database connection script
if(isset($_GET['item']) && isset($_GET['tipo']) && isset($_GET['coap2'])&& isset($_GET['coap3'])&& isset($_GET['cn'])&& isset($_GET['sbc'])&& isset($_GET['pert'])){
	$created = date("Y-m-d", strtotime("now"));
	$item = $mysqli->real_escape_string($_GET['item']);
	$tipo = $mysqli->real_escape_string($_GET['tipo']);
	$coap2 = $mysqli->real_escape_string($_GET['coap2']);
	$coap3 = $mysqli->real_escape_string($_GET['coap3']);
	$cn = $mysqli->real_escape_string($_GET['cn']);
	$sbc = $mysqli->real_escape_string($_GET['sbc']);
	$pert = $mysqli->real_escape_string($_GET['pert']);
	$status = "0";
	

	$query="INSERT INTO ApiCountry.paises(id,fecha, nombre, tipo, codigo_alpha2, codigo_alpha3, codigo_numerico,subdivision_codes,pertenece,status)  VALUES('NULL',now(),'$item','$tipo','$coap2','$coap3','$cn','$sbc','$pert','$status')";
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);

	$result = $mysqli->affected_rows;

	echo $json_response = json_encode($result);
	}
?>