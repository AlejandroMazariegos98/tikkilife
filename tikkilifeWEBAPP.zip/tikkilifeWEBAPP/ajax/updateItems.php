<?php 
require_once '../includes/db.php'; // The mysql database connection script
if(isset($_GET['itemID']) && isset($_GET['tipo']) && isset($_GET['coap2'])&& isset($_GET['coap3'])&& isset($_GET['cn'])&& isset($_GET['sbc'])&& isset($_GET['pert'])){
	
	$itemID = $mysqli->real_escape_string($_GET['itemID']);
	$tipo = $mysqli->real_escape_string($_GET['tipo']);
	$coap2 = $mysqli->real_escape_string($_GET['coap2']);
	$coap3 = $mysqli->real_escape_string($_GET['coap3']);
	$cn = $mysqli->real_escape_string($_GET['cn']);
	$sbc = $mysqli->real_escape_string($_GET['sbc']);
	$pert = $mysqli->real_escape_string($_GET['pert']);

	$query="UPDATE paises set stipo='$tipo', codigo_alpha2='$coap2', codigo_alpha3='$coap3', codigo_numerico='$cn', subdivision_codes='$sbc', pertenece='$pert' where id='$itemID'";
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);

	$result = $mysqli->affected_rows;

	$json_response = json_encode($result);
}
?>