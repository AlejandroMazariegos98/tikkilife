<?php 
require_once '../includes/db.php'; // The mysql database connection script

if(isset($_GET['itemID'])){
	$itemID = $mysqli->real_escape_string($_GET['itemID']);
}
$query="SELECT id,fecha,nombre,tipo,codigo_alpha2,codigo_alpha3,codigo_numerico,subdivision_codes,pertenece from paises where id like $itemID order by id desc";
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);

$arr = array();
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$arr[] = $row;	
	}
}

# JSON-encode the response
echo $json_response = json_encode($arr);
?>