<?php 
$DB_HOST = 'ApiCountry.db.10408002.95e.hostedresource.net';
$DB_USER = 'ApiCountry';
$DB_PASS = 'Webapp1234@';
$DB_NAME = 'ApiCountry';
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>
